﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace hotelbookings
{
    class db
    {
        public SqlConnection con;
        public db()
        {
            try
            {
                string str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Ahamed\Documents\hotel_bookings.mdf;Integrated Security=True;Connect Timeout=30";
                con=new SqlConnection (str);

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);   
            }
        }
    }
}
