﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hotelbookings
{
    public partial class clientf : Form
    {
        public clientf()
        {
            InitializeComponent();
        }
        db o = new db();
        private void label2_Click(object sender, EventArgs e)
        {

        }

        
        
        private void button1_Click(object sender, EventArgs e)
        {
            
            if (txtcid.Text == "")
            {
                MessageBox.Show("enter ID");
                txtcid.Focus();
                return;
            }
            if (txtcfn.Text == "")
            {
                MessageBox.Show("enter first name");
                txtcfn.Focus();
                return;
            }
            if (txtcln.Text == "")
            {
                MessageBox.Show("enter last name");
                txtcln.Focus();
                return;
            }
            if (txtceid.Text == "")
            {
                MessageBox.Show("enter email");
                txtceid.Focus();
                return;
            }
            if (txtcpn.Text == "")
            {
                MessageBox.Show("enter phone no");
                txtcpn.Focus();
                return;
            }
            if (cmbcselectId.Text == "")
            {
                MessageBox.Show("enter id");
                cmbcselectId.Focus();
                return;
            }
            if (txtcidno.Text == "")
            {
                MessageBox.Show("enter id no");
                txtcidno.Focus();
                return;
            }
            try
            {
                o.con.Open();
                SqlCommand cmd = new SqlCommand("insert into client values('" + txtcid.Text + "' , '" + txtcfn.Text + "','" + txtcln.Text + "' , '" + txtceid.Text + "' , '" + txtcpn.Text + "' , '" + cmbcselectId.Text + "' , '" + txtcidno.Text + "') " , o.con);
                SqlDataReader dr = cmd.ExecuteReader();
                MessageBox.Show("client added");
                o.con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                o.con.Close();
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            mainf f1 = new mainf();
            this.Hide();
            f1.Show();
        }

        private void clientf_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hotel_bookingsDataSet2.client' table. You can move, or remove it, as needed.
          
            // TODO: This line of code loads data into the 'hotel_bookingsDataSet1.client' table. You can move, or remove it, as needed.
          

        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            if (txtcid.Text == "")
            {
                MessageBox.Show("enter ID");
                txtcid.Focus();
                return;
            }
            if (txtcfn.Text == "")
            {
                MessageBox.Show("enter first name");
                txtcfn.Focus();
                return;
            }
            if (txtcln.Text == "")
            {
                MessageBox.Show("enter last name");
                txtcln.Focus();
                return;
            }
            if (txtceid.Text == "")
            {
                MessageBox.Show("enter email");
                txtceid.Focus();
                return;
            }
            if (txtcpn.Text == "")
            {
                MessageBox.Show("enter phone no");
                txtcpn.Focus();
                return;
            }
            if (cmbcselectId.Text == "")
            {
                MessageBox.Show("enter id");
                cmbcselectId.Focus();
                return;
            }
            if (txtcidno.Text == "")
            {
                MessageBox.Show("enter id no");
                txtcidno.Focus();
                return;
            }
            try
            {
                o.con.Open();
                SqlCommand cmd = new SqlCommand("delete from client where Id='"+txtcid.Text+"' ", o.con);
                SqlDataReader dr = cmd.ExecuteReader();
                MessageBox.Show("Data deleted");
                o.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                o.con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            o.con.Open();
            SqlCommand cmd = new SqlCommand("select * from client",o.con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            o.con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            o.con.Open();
            SqlCommand cmd = new SqlCommand("update client where Id='" + txtcid.Text + "' ",o.con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("data updated");
            o.con.Close();
        }

        private void cmbcselectId_SelectedIndexChanged(object sender, EventArgs e)
        {
          

        }
    }
}