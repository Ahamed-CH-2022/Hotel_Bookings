﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hotelbookings
{
    public partial class roomf : Form
    {
        public roomf()
        {
            InitializeComponent();
        }
        db o = new db();
        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_rno.Text == "")
            {
                MessageBox.Show("ENTER ROOM NO");
                txt_rno.Focus();
                return;
            }
            if (txt_type.Text == "")
            {
                MessageBox.Show("ENTER ROOM TYPE");
                txt_type.Focus();
                return;
            }
            if (txt_phno.Text == "")
            {
                MessageBox.Show("ENTER PHONE NO");
                txt_phno.Focus();
                return;
            }
            try
            {
                o.con.Open();
                SqlCommand cmd = new SqlCommand("insert into room values('" + txt_rno.Text + "','"+txt_type.Text+"','"+txt_phno.Text+"' )",o.con);
                SqlDataReader dr = cmd.ExecuteReader();
                MessageBox.Show("room added");
                o.con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                o.con.Close();
            }
        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            o.con.Open();
            SqlCommand cmd = new SqlCommand("select * from room", o.con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            o.con.Close();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_rno.Text == "")
            {
                MessageBox.Show("enter id");
                txt_rno.Focus();
                return;
            }
            if (txt_type.Text == "")
            {
                MessageBox.Show("enter id no");
                txt_type.Focus();
                return;
            }
            if (txt_phno.Text == "")
            {
                MessageBox.Show("enter id no");
                txt_phno.Focus();
                return;
            }
            try
            {
                o.con.Open();
                SqlCommand cmd = new SqlCommand("delete from room where Room_no='" + txt_rno.Text + "' ", o.con);
                SqlDataReader dr = cmd.ExecuteReader();
                MessageBox.Show("Data deleted");
                o.con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                o.con.Close();
            }
        }

        private void roomf_Load(object sender, EventArgs e)
        {

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            mainf f1 = new hotelbookings.mainf();
            this.Hide();
            f1.Show();
        }
    }
}
