﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotelbookings
{
    public partial class mainf : Form
    {
        public mainf()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            roomf f12 = new roomf();
            this.Hide();
            f12.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            clientf  f11 = new clientf();
            this.Hide();
            f11.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loginf f0 = new loginf();
            this.Hide();
            f0.Show();
        }
    }
}
