﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace hotelbookings
{
    public partial class loginf : Form
    {
        public loginf()
        {
            InitializeComponent();
        }
        db o = new db();
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnsignin_Click(object sender, EventArgs e)
        {
           if(txtuser.Text=="")
            {
                MessageBox.Show("enter username");
                txtuser.Focus();
                return;
            }
           if(txtpass.Text=="")
            {
                MessageBox.Show("enter password");
                txtpass.Focus();
                return;
            }
           try
            {
                
                SqlCommand cmd = new SqlCommand("select username, password from login where username='"+txtuser.Text +"' and password='"+txtpass.Text +"'",o.con );
                o.con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                
                if(dr.Read())
                {
                    mainf f1 = new hotelbookings.mainf();
                    this.Hide();
                    f1.Show();
                    o.con.Close();
                }
                else
                {
                    MessageBox.Show("invalid user");
                    o.con.Close();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
