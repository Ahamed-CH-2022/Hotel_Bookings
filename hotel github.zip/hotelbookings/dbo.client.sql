﻿CREATE TABLE [dbo].[client] (
    [ID]         INT          NOT NULL,
    [First name] NCHAR (10)   NULL,
    [Last name]  NCHAR (10)   NULL,
    [Email ID]   VARCHAR (50) NULL,
    [Ph no]      INT          NULL,
    [Select ID]  VARCHAR (50) NULL,
    [ID no]      INT          NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

