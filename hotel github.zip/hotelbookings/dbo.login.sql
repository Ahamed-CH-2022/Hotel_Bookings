﻿CREATE TABLE [dbo].[login] (
    [Id]       INT           NOT NULL,
    [username] NVARCHAR (50) NULL,
    [password] NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

